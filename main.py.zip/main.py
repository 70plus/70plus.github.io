from turtle import *

def branch(level,size):
  global resize
  if level == 0:
      return (True)
  else:
    curr_color = color()[0]
    if level == 1:
      color(color_list[-1])
    else:
      color(color_list[1])
    for i in rot:
      right(i)
      forward(size)
      branch(level-1,size/resize)
      backward(size)
      left(i)
    color(curr_color)
    return(True)

# configura l'albero
size, resize = 120, 1.3
pensize(1.5)
rot = [-45,-15,20,40]
color_list = ['darkgoldenrod','goldenrod','pink']
level = 5

# traccia l'albero
hideturtle()
color(color_list[0])
left(90)
penup()
sety(-size*resize)
pendown()
forward(size)
branch(level,size/resize)

# export image as ps
getscreen().getcanvas().postscript(file='albero.ps')